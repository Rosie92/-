package poly.dto;

public class TestDTO {

	private String seq1;
	private String seq2;
	private String seq3;
	private String seq4;
	private String seq5;
	private String seq6;
	private String seq7;
	private String seq8;

	public String getSeq1() {
		return seq1;
	}

	public void setSeq1(String seq1) {
		this.seq1 = seq1;
	}

	public String getSeq2() {
		return seq2;
	}

	public void setSeq2(String seq2) {
		this.seq2 = seq2;
	}

	public String getSeq3() {
		return seq3;
	}

	public void setSeq3(String seq3) {
		this.seq3 = seq3;
	}

	public String getSeq4() {
		return seq4;
	}

	public void setSeq4(String seq4) {
		this.seq4 = seq4;
	}

	public String getSeq5() {
		return seq5;
	}

	public void setSeq5(String seq5) {
		this.seq5 = seq5;
	}

	public String getSeq6() {
		return seq6;
	}

	public void setSeq6(String seq6) {
		this.seq6 = seq6;
	}

	public String getSeq7() {
		return seq7;
	}

	public void setSeq7(String seq7) {
		this.seq7 = seq7;
	}

	public String getSeq8() {
		return seq8;
	}

	public void setSeq8(String seq8) {
		this.seq8 = seq8;
	}

}
