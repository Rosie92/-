package poly.dto;

import java.io.Serializable;

public class MyJsonDTO implements Serializable {

	private String name = "";
	private String email = "";
	private String addr = "";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

}
