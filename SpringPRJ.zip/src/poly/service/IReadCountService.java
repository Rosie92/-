package poly.service;

public interface IReadCountService {

	// HDFS에서 MongoDB 저장하기
	int Hdfs2MongoForReadCount() throws Exception;
	
}
