package poly.service;

public interface IMovieService {

	// 웹상(CGV 홈페이지)에서 영화 순위정보 가져오기
	int getMovieInfoFromWEB() throws Exception;
	
}
